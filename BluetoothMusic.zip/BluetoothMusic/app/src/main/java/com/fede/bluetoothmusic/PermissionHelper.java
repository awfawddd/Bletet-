package com.fede.bluetoothmusic;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * PermissionHelper
 * ----------------
 * Classe di utilita' per chiedere i permessi a "runtime".
 *
 * ATTENZIONE - errore classico: dichiarare i permessi nel Manifest NON basta.
 * Da Android 6 in poi i permessi "pericolosi" (Bluetooth, file, ecc.) vanno
 * anche CHIESTI mentre l'app gira, con una finestra di dialogo. Se salti
 * questo passaggio l'app parte ma non vede nessun dispositivo e sembra rotta.
 */
public class PermissionHelper {

    // Codice identificativo: ce lo ritroveremo in onRequestPermissionsResult.
    public static final int RICHIESTA_PERMESSI = 100;

    // L'elenco dei permessi che ci servono (validi da Android 12 / SDK 31).
    private static final String[] PERMESSI_NECESSARI = {
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS
    };

    /**
     * Controlla se TUTTI i permessi sono gia' stati concessi.
     * @return true se non manca niente, false se ne manca almeno uno.
     */
    public static boolean haTuttiIPermessi(Activity activity) {
        for (String permesso : PERMESSI_NECESSARI) {
            if (ContextCompat.checkSelfPermission(activity, permesso)
                    != PackageManager.PERMISSION_GRANTED) {
                return false; // appena ne trovo uno mancante, mi fermo
            }
        }
        return true;
    }

    /**
     * Mostra all'utente le finestre di richiesta permessi.
     * La risposta arrivera' in MainActivity.onRequestPermissionsResult().
     */
    public static void chiediPermessi(Activity activity) {
        ActivityCompat.requestPermissions(
                activity,
                PERMESSI_NECESSARI,
                RICHIESTA_PERMESSI
        );
    }
}
