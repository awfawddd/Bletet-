package com.fede.bluetoothmusic;

/**
 * DispositivoBT
 * -------------
 * Semplice "contenitore di dati" che rappresenta UN dispositivo Bluetooth
 * trovato durante la scansione. Tiene insieme nome, indirizzo MAC, tipo
 * (auto, speaker, ecc.) e se e' gia' accoppiato.
 *
 * E' una classe "modello": non ha logica, serve solo a trasportare dati
 * dallo scanner alla lista che vede l'utente.
 */
public class DispositivoBT {

    // Tipi possibili di dispositivo. Un "enum" e' un elenco chiuso di valori.
    public enum Tipo {
        AUTO,       // stereo / impianto dell'auto
        SPEAKER,    // cassa Bluetooth
        CUFFIE,     // cuffie o auricolari
        TELEFONO,   // un altro telefono
        COMPUTER,   // pc / portatile
        ALTRO       // tutto il resto
    }

    private final String nome;
    private final String indirizzoMac;
    private final Tipo tipo;
    private final boolean giaAccoppiato;

    public DispositivoBT(String nome, String indirizzoMac, Tipo tipo, boolean giaAccoppiato) {
        // Se il dispositivo non espone un nome, mettiamo un testo di ripiego.
        this.nome = (nome == null || nome.isEmpty()) ? "Dispositivo sconosciuto" : nome;
        this.indirizzoMac = indirizzoMac;
        this.tipo = tipo;
        this.giaAccoppiato = giaAccoppiato;
    }

    public String getNome() { return nome; }
    public String getIndirizzoMac() { return indirizzoMac; }
    public Tipo getTipo() { return tipo; }
    public boolean isGiaAccoppiato() { return giaAccoppiato; }

    /** Restituisce un'emoji-icona a seconda del tipo, per la lista. */
    public String getIcona() {
        switch (tipo) {
            case AUTO:     return "\uD83D\uDE97"; // auto
            case SPEAKER:  return "\uD83D\uDD0A"; // altoparlante
            case CUFFIE:   return "\uD83C\uDFA7"; // cuffie
            case TELEFONO: return "\uD83D\uDCF1"; // telefono
            case COMPUTER: return "\uD83D\uDCBB"; // computer
            default:       return "\uD83D\uDCE1"; // antenna
        }
    }

    /**
     * Due dispositivi sono "lo stesso" se hanno lo stesso indirizzo MAC.
     * Serve per evitare doppioni nella lista durante la scansione.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof DispositivoBT)) return false;
        return indirizzoMac.equals(((DispositivoBT) o).indirizzoMac);
    }

    @Override
    public int hashCode() {
        return indirizzoMac.hashCode();
    }
}
