package com.fede.bluetoothmusic;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * BluetoothScanner
 * ----------------
 * Si occupa di:
 *  1) leggere i dispositivi GIA' accoppiati;
 *  2) avviare una scansione (discovery) per trovare quelli nuovi nelle vicinanze;
 *  3) capire il TIPO di ogni dispositivo (auto, speaker, cuffie...).
 *
 * Come funziona la scansione in Android: si chiama startDiscovery() e poi
 * Android invia dei "broadcast" (messaggi di sistema) ogni volta che trova
 * un dispositivo. Noi li intercettiamo con un BroadcastReceiver.
 */
public class BluetoothScanner {

    /** Interfaccia di callback: chi usa lo scanner riceve qui gli aggiornamenti. */
    public interface ScannerListener {
        void onDispositivoTrovato(DispositivoBT dispositivo);
        void onScansioneFinita();
        void onErrore(String messaggio);
    }

    private final Context context;
    private final BluetoothAdapter bluetoothAdapter;
    private final ScannerListener listener;
    private boolean receiverRegistrato = false;

    public BluetoothScanner(Context context, ScannerListener listener) {
        this.context = context;
        this.listener = listener;
        // BluetoothManager e' il "punto d'ingresso" al Bluetooth del sistema.
        BluetoothManager manager =
                (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        this.bluetoothAdapter = manager.getAdapter();
    }

    /** @return true se il dispositivo ha il Bluetooth e risulta acceso. */
    public boolean bluetoothDisponibile() {
        return bluetoothAdapter != null && bluetoothAdapter.isEnabled();
    }

    /**
     * Restituisce subito la lista dei dispositivi GIA' accoppiati.
     * Questi non vanno cercati: il sistema li conosce gia'.
     */
    public List<DispositivoBT> getDispositiviAccoppiati() {
        List<DispositivoBT> risultato = new ArrayList<>();
        if (!haPermessoConnect()) {
            return risultato; // senza permesso restituiamo lista vuota
        }
        Set<BluetoothDevice> accoppiati = bluetoothAdapter.getBondedDevices();
        for (BluetoothDevice device : accoppiati) {
            risultato.add(creaDispositivo(device, true));
        }
        return risultato;
    }

    /**
     * Avvia la scansione dei dispositivi vicini non ancora accoppiati.
     */
    public void avviaScansione() {
        if (!haPermessoScan() || !haPermessoConnect()) {
            listener.onErrore("Permessi Bluetooth non concessi");
            return;
        }
        if (bluetoothAdapter == null) {
            listener.onErrore("Questo dispositivo non ha il Bluetooth");
            return;
        }
        if (!bluetoothAdapter.isEnabled()) {
            listener.onErrore("Attiva il Bluetooth e riprova");
            return;
        }

        // Registriamo il receiver per ricevere gli "annunci" di Android.
        if (!receiverRegistrato) {
            IntentFilter filtro = new IntentFilter();
            filtro.addAction(BluetoothDevice.ACTION_FOUND);          // trovato un device
            filtro.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED); // scansione finita
            context.registerReceiver(receiver, filtro);
            receiverRegistrato = true;
        }

        // Se una scansione era gia' in corso, la fermiamo prima di ripartire.
        if (bluetoothAdapter.isDiscovering()) {
            bluetoothAdapter.cancelDiscovery();
        }
        bluetoothAdapter.startDiscovery();
    }

    /** Ferma la scansione e libera il receiver. Da chiamare quando l'app si chiude. */
    public void ferma() {
        if (bluetoothAdapter != null && haPermessoScan()
                && bluetoothAdapter.isDiscovering()) {
            bluetoothAdapter.cancelDiscovery();
        }
        if (receiverRegistrato) {
            try {
                context.unregisterReceiver(receiver);
            } catch (IllegalArgumentException ignorato) {
                // gia' tolto: nessun problema
            }
            receiverRegistrato = false;
        }
    }

    // BroadcastReceiver: il "ricevitore" dei messaggi di sistema sul Bluetooth.
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context ctx, Intent intent) {
            String azione = intent.getAction();

            if (BluetoothDevice.ACTION_FOUND.equals(azione)) {
                // Android ci sta passando un dispositivo trovato.
                BluetoothDevice device =
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device != null && haPermessoConnect()) {
                    listener.onDispositivoTrovato(creaDispositivo(device, false));
                }
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(azione)) {
                listener.onScansioneFinita();
            }
        }
    };

    /** Trasforma un BluetoothDevice di sistema nel nostro modello DispositivoBT. */
    private DispositivoBT creaDispositivo(BluetoothDevice device, boolean accoppiato) {
        String nome = null;
        if (haPermessoConnect()) {
            nome = device.getName(); // puo' essere null se il device non lo espone
        }
        DispositivoBT.Tipo tipo = ricavaTipo(device);
        return new DispositivoBT(nome, device.getAddress(), tipo, accoppiato);
    }

    /**
     * Capisce il tipo di dispositivo leggendo la "Bluetooth Class of Device".
     * Ogni dispositivo BT dichiara una classe che dice cos'e'.
     */
    private DispositivoBT.Tipo ricavaTipo(BluetoothDevice device) {
        BluetoothClass btClass = device.getBluetoothClass();
        if (btClass == null) {
            return DispositivoBT.Tipo.ALTRO;
        }
        switch (btClass.getDeviceClass()) {
            case BluetoothClass.Device.AUDIO_VIDEO_CAR_AUDIO:
                return DispositivoBT.Tipo.AUTO;
            case BluetoothClass.Device.AUDIO_VIDEO_LOUDSPEAKER:
            case BluetoothClass.Device.AUDIO_VIDEO_PORTABLE_AUDIO:
            case BluetoothClass.Device.AUDIO_VIDEO_HIFI_AUDIO:
                return DispositivoBT.Tipo.SPEAKER;
            case BluetoothClass.Device.AUDIO_VIDEO_HEADPHONES:
            case BluetoothClass.Device.AUDIO_VIDEO_WEARABLE_HEADSET:
            case BluetoothClass.Device.AUDIO_VIDEO_HANDSFREE:
                return DispositivoBT.Tipo.CUFFIE;
            case BluetoothClass.Device.PHONE_SMART:
            case BluetoothClass.Device.PHONE_CELLULAR:
                return DispositivoBT.Tipo.TELEFONO;
            case BluetoothClass.Device.COMPUTER_DESKTOP:
            case BluetoothClass.Device.COMPUTER_LAPTOP:
                return DispositivoBT.Tipo.COMPUTER;
            default:
                // Controllo piu' largo: se la "major class" e' audio/video.
                if (btClass.getMajorDeviceClass()
                        == BluetoothClass.Device.Major.AUDIO_VIDEO) {
                    return DispositivoBT.Tipo.SPEAKER;
                }
                return DispositivoBT.Tipo.ALTRO;
        }
    }

    // --- piccoli helper per leggere i permessi ---
    private boolean haPermessoScan() {
        return ActivityCompat.checkSelfPermission(context,
                Manifest.permission.BLUETOOTH_SCAN)
                == PackageManager.PERMISSION_GRANTED;
    }

    private boolean haPermessoConnect() {
        return ActivityCompat.checkSelfPermission(context,
                Manifest.permission.BLUETOOTH_CONNECT)
                == PackageManager.PERMISSION_GRANTED;
    }
}
