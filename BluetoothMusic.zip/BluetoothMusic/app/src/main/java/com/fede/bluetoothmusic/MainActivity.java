package com.fede.bluetoothmusic;

import android.bluetooth.BluetoothAdapter;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * MainActivity
 * ------------
 * La schermata principale. Tiene insieme le tre sezioni dell'app:
 *
 *   1) BLUETOOTH  - scansiona e mostra i dispositivi (auto, casse, ecc.)
 *   2) MUSICA     - player dei brani sul telefono
 *   3) YOUTUBE    - player ufficiale di YouTube in una WebView
 *
 * Per tenere il codice semplice usiamo UNA sola Activity con tre "pannelli"
 * che mostriamo/nascondiamo con i tre pulsanti in alto.
 */
public class MainActivity extends AppCompatActivity
        implements BluetoothScanner.ScannerListener {

    // I tre pannelli (sezioni) dell'interfaccia.
    private LinearLayout pannelloBluetooth, pannelloMusica, pannelloYoutube;

    // --- sezione Bluetooth ---
    private BluetoothScanner scanner;
    private ArrayAdapter<String> adapterBT;
    private final List<DispositivoBT> dispositiviTrovati = new ArrayList<>();
    private TextView statoBT;

    // --- sezione Musica ---
    private MusicPlayerService musicService;
    private boolean serviceCollegato = false;
    private ArrayAdapter<String> adapterMusica;
    private final List<Brano> brani = new ArrayList<>();
    private TextView statoMusica;

    // --- sezione YouTube ---
    private WebView webView;

    /**
     * ServiceConnection: gestisce il collegamento al MusicPlayerService.
     * onServiceConnected scatta quando il "ponte" col service e' pronto.
     */
    private final ServiceConnection connessioneService = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName nome, IBinder binder) {
            MusicPlayerService.LocalBinder b = (MusicPlayerService.LocalBinder) binder;
            musicService = b.getService();
            serviceCollegato = true;
        }
        @Override
        public void onServiceDisconnected(ComponentName nome) {
            serviceCollegato = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        collegaViste();
        configuraSezioneBluetooth();
        configuraSezioneMusica();
        configuraSezioneYoutube();

        // All'avvio chiediamo subito i permessi se mancano.
        if (!PermissionHelper.haTuttiIPermessi(this)) {
            PermissionHelper.chiediPermessi(this);
        }

        // Avviamo e ci colleghiamo al service della musica.
        Intent intentService = new Intent(this, MusicPlayerService.class);
        startService(intentService);
        bindService(intentService, connessioneService, Context.BIND_AUTO_CREATE);

        // Mostriamo la sezione Bluetooth come schermata iniziale.
        mostraPannello(pannelloBluetooth);
    }

    /** Collega le variabili Java agli elementi grafici del layout XML. */
    private void collegaViste() {
        pannelloBluetooth = findViewById(R.id.pannelloBluetooth);
        pannelloMusica    = findViewById(R.id.pannelloMusica);
        pannelloYoutube   = findViewById(R.id.pannelloYoutube);

        // I tre pulsanti del menu in alto.
        Button btnTabBT      = findViewById(R.id.btnTabBluetooth);
        Button btnTabMusica  = findViewById(R.id.btnTabMusica);
        Button btnTabYoutube = findViewById(R.id.btnTabYoutube);

        btnTabBT.setOnClickListener(v -> mostraPannello(pannelloBluetooth));
        btnTabMusica.setOnClickListener(v -> mostraPannello(pannelloMusica));
        btnTabYoutube.setOnClickListener(v -> mostraPannello(pannelloYoutube));
    }

    /** Mostra un pannello e nasconde gli altri due. */
    private void mostraPannello(LinearLayout daMostrare) {
        pannelloBluetooth.setVisibility(View.GONE);
        pannelloMusica.setVisibility(View.GONE);
        pannelloYoutube.setVisibility(View.GONE);
        daMostrare.setVisibility(View.VISIBLE);
    }

    // ==================== SEZIONE BLUETOOTH ====================

    private void configuraSezioneBluetooth() {
        statoBT = findViewById(R.id.statoBT);
        ListView listaBT = findViewById(R.id.listaBT);
        Button btnScansiona = findViewById(R.id.btnScansiona);
        Button btnImpostazioni = findViewById(R.id.btnImpostazioniBT);

        // L'adapter collega la lista di testi alla ListView a schermo.
        adapterBT = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
                new ArrayList<>());
        listaBT.setAdapter(adapterBT);

        scanner = new BluetoothScanner(this, this);

        btnScansiona.setOnClickListener(v -> avviaScansioneBT());

        // Apre le Impostazioni Bluetooth di sistema: e' qui che l'utente
        // accoppia un nuovo dispositivo. Un'app NON puo' forzare
        // l'accoppiamento audio (A2DP): lo gestisce Android per sicurezza.
        btnImpostazioni.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));

        // Quando si tocca un dispositivo della lista, apriamo le impostazioni.
        listaBT.setOnItemClickListener((parent, view, posizione, id) -> {
            Toast.makeText(this,
                    "Per collegarti, accoppia il dispositivo dalle Impostazioni",
                    Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        });
    }

    private void avviaScansioneBT() {
        if (!PermissionHelper.haTuttiIPermessi(this)) {
            PermissionHelper.chiediPermessi(this);
            return;
        }
        // Svuotiamo la lista e ripartiamo.
        dispositiviTrovati.clear();
        adapterBT.clear();

        // Prima aggiungiamo i dispositivi GIA' accoppiati.
        for (DispositivoBT d : scanner.getDispositiviAccoppiati()) {
            aggiungiDispositivoInLista(d);
        }

        // Poi avviamo la ricerca di quelli nuovi.
        statoBT.setText("Scansione in corso...");
        scanner.avviaScansione();
    }

    private void aggiungiDispositivoInLista(DispositivoBT d) {
        if (dispositiviTrovati.contains(d)) {
            return; // gia' presente: niente doppioni
        }
        dispositiviTrovati.add(d);
        String etichetta = d.getIcona() + "  " + d.getNome()
                + (d.isGiaAccoppiato() ? "  (accoppiato)" : "")
                + "\n" + d.getIndirizzoMac();
        adapterBT.add(etichetta);
    }

    // Metodi richiesti da BluetoothScanner.ScannerListener:

    @Override
    public void onDispositivoTrovato(DispositivoBT dispositivo) {
        runOnUiThread(() -> aggiungiDispositivoInLista(dispositivo));
    }

    @Override
    public void onScansioneFinita() {
        runOnUiThread(() -> statoBT.setText(
                "Trovati " + dispositiviTrovati.size() + " dispositivi"));
    }

    @Override
    public void onErrore(String messaggio) {
        runOnUiThread(() -> {
            statoBT.setText(messaggio);
            Toast.makeText(this, messaggio, Toast.LENGTH_LONG).show();
        });
    }

    // ==================== SEZIONE MUSICA ====================

    private void configuraSezioneMusica() {
        statoMusica = findViewById(R.id.statoMusica);
        ListView listaMusica = findViewById(R.id.listaMusica);
        Button btnCarica = findViewById(R.id.btnCaricaMusica);
        Button btnPlay = findViewById(R.id.btnPlay);
        Button btnPausa = findViewById(R.id.btnPausa);
        Button btnPrec = findViewById(R.id.btnPrecedente);
        Button btnNext = findViewById(R.id.btnProssimo);

        adapterMusica = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, new ArrayList<>());
        listaMusica.setAdapter(adapterMusica);

        btnCarica.setOnClickListener(v -> caricaBrani());

        // Toccando un brano della lista, lo riproduciamo.
        listaMusica.setOnItemClickListener((parent, view, posizione, id) -> {
            if (serviceCollegato) {
                musicService.riproduci(posizione);
                statoMusica.setText("In riproduzione: "
                        + brani.get(posizione).getTitolo());
            }
        });

        btnPlay.setOnClickListener(v -> { if (serviceCollegato) musicService.play(); });
        btnPausa.setOnClickListener(v -> { if (serviceCollegato) musicService.pausa(); });
        btnPrec.setOnClickListener(v -> { if (serviceCollegato) musicService.precedente(); });
        btnNext.setOnClickListener(v -> { if (serviceCollegato) musicService.prossimo(); });
    }

    private void caricaBrani() {
        if (!PermissionHelper.haTuttiIPermessi(this)) {
            PermissionHelper.chiediPermessi(this);
            return;
        }
        brani.clear();
        adapterMusica.clear();

        brani.addAll(LettoreMusica.leggiBrani(this));
        for (Brano b : brani) {
            adapterMusica.add(b.getTitolo() + "\n" + b.getArtista());
        }
        statoMusica.setText("Trovati " + brani.size() + " brani");

        if (serviceCollegato) {
            musicService.caricaPlaylist(brani);
        }
    }

    // ==================== SEZIONE YOUTUBE ====================

    private void configuraSezioneYoutube() {
        webView = findViewById(R.id.webViewYoutube);
        EditText campoRicerca = findViewById(R.id.campoRicercaYoutube);
        Button btnCerca = findViewById(R.id.btnCercaYoutube);

        // Abilitiamo JavaScript: serve al player di YouTube per funzionare.
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Pagina iniziale.
        webView.loadUrl("https://m.youtube.com");

        btnCerca.setOnClickListener(v -> {
            String testo = campoRicerca.getText().toString().trim();
            if (!testo.isEmpty()) {
                // Apriamo la ricerca di YouTube. Usiamo il sito ufficiale:
                // e' la via pulita, nel rispetto dei termini di YouTube.
                String url = "https://m.youtube.com/results?search_query="
                        + android.net.Uri.encode(testo);
                webView.loadUrl(url);
            }
        });
    }

    // ==================== PERMESSI ====================

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PermissionHelper.RICHIESTA_PERMESSI) {
            if (PermissionHelper.haTuttiIPermessi(this)) {
                Toast.makeText(this, "Permessi concessi",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this,
                        "Senza i permessi l'app non puo' funzionare del tutto",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    // ==================== CICLO DI VITA ====================

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Puliamo tutto per non lasciare risorse appese.
        if (scanner != null) {
            scanner.ferma();
        }
        if (serviceCollegato) {
            unbindService(connessioneService);
            serviceCollegato = false;
        }
    }
}
