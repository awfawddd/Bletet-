package com.fede.bluetoothmusic;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

import java.util.ArrayList;
import java.util.List;

/**
 * LettoreMusica
 * -------------
 * Legge tutte le canzoni presenti nella memoria del telefono.
 *
 * Android tiene un "catalogo" di tutti i file multimediali: si chiama
 * MediaStore. Invece di scandire le cartelle a mano, facciamo una
 * "query" a questo catalogo e ci facciamo restituire l'elenco audio.
 *
 * Serve il permesso READ_MEDIA_AUDIO (gia' chiesto da PermissionHelper).
 */
public class LettoreMusica {

    /**
     * @return la lista di tutti i brani audio trovati sul telefono.
     */
    public static List<Brano> leggiBrani(Context context) {
        List<Brano> brani = new ArrayList<>();

        // Le colonne del catalogo che ci interessano.
        String[] colonne = {
                MediaStore.Audio.Media._ID,      // identificativo del file
                MediaStore.Audio.Media.TITLE,    // titolo
                MediaStore.Audio.Media.ARTIST    // artista
        };

        // Filtro: vogliamo solo i file che sono davvero brani musicali
        // (esclude suonerie, notifiche, registrazioni vocali...).
        String filtro = MediaStore.Audio.Media.IS_MUSIC + " != 0";

        // Ordine: alfabetico per titolo.
        String ordine = MediaStore.Audio.Media.TITLE + " ASC";

        ContentResolver resolver = context.getContentResolver();

        // try-with-resources: il Cursor viene chiuso automaticamente alla fine.
        try (Cursor cursor = resolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                colonne, filtro, null, ordine)) {

            if (cursor != null) {
                int colId     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
                int colTitolo = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
                int colArtista= cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);

                // Scorriamo riga per riga il risultato.
                while (cursor.moveToNext()) {
                    long id = cursor.getLong(colId);
                    String titolo = cursor.getString(colTitolo);
                    String artista = cursor.getString(colArtista);

                    // Costruiamo l'URI completo del file partendo dal suo id.
                    Uri uri = ContentUris.withAppendedId(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);

                    brani.add(new Brano(titolo, artista, uri));
                }
            }
        }
        return brani;
    }
}
