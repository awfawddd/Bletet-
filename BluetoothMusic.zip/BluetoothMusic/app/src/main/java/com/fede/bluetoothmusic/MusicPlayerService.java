package com.fede.bluetoothmusic;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

import androidx.annotation.OptIn;
import androidx.core.app.NotificationCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;

import java.util.ArrayList;
import java.util.List;

/**
 * MusicPlayerService
 * ------------------
 * Un "Service" e' una parte dell'app che gira SENZA interfaccia, anche
 * quando l'utente non sta guardando l'app. Lo usiamo per la musica:
 * cosi' continua a suonare se metti il telefono in tasca.
 *
 * E' un "foreground service": deve mostrare una notifica fissa, altrimenti
 * Android lo chiude. La notifica e' obbligatoria, non e' un optional.
 *
 * Per riprodurre l'audio usiamo ExoPlayer (libreria Media3 di Google):
 * piu' potente e affidabile del vecchio MediaPlayer.
 *
 * Nota Bluetooth: non dobbiamo fare NULLA di speciale per far uscire
 * l'audio sulla cassa/auto. Se il dispositivo BT e' collegato a livello
 * di sistema, Android ci manda sopra l'audio automaticamente.
 */
@OptIn(markerClass = UnstableApi.class)
public class MusicPlayerService extends Service {

    private static final String CANALE_ID = "canale_musica";
    private static final int NOTIFICA_ID = 1;

    private ExoPlayer player;
    private final IBinder binder = new LocalBinder();

    // Lista delle canzoni caricate (path + titolo).
    private List<Brano> playlist = new ArrayList<>();

    /**
     * Binder: il "ponte" che permette a MainActivity di parlare con il service
     * chiamando direttamente i suoi metodi (play, pausa, ecc.).
     */
    public class LocalBinder extends Binder {
        public MusicPlayerService getService() {
            return MusicPlayerService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        creaCanaleNotifica();
        // Creiamo il player una sola volta, alla nascita del service.
        player = new ExoPlayer.Builder(this).build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Facciamo partire il service in "foreground" con la sua notifica.
        startForeground(NOTIFICA_ID, creaNotifica("Pronto"));
        return START_STICKY;
    }

    /** Carica una lista di brani nel player. */
    public void caricaPlaylist(List<Brano> brani) {
        this.playlist = brani;
        player.clearMediaItems();
        for (Brano b : brani) {
            // Ogni brano diventa un MediaItem identificato dal suo URI.
            player.addMediaItem(MediaItem.fromUri(b.getUri()));
        }
        player.prepare(); // prepara la riproduzione (non parte ancora)
    }

    /** Fa partire (o riprende) la riproduzione del brano alla posizione data. */
    public void riproduci(int indice) {
        if (indice >= 0 && indice < playlist.size()) {
            player.seekTo(indice, 0);
            player.play();
            aggiornaNotifica(playlist.get(indice).getTitolo());
        }
    }

    public void play() {
        player.play();
    }

    public void pausa() {
        player.pause();
    }

    public void prossimo() {
        if (player.hasNextMediaItem()) {
            player.seekToNextMediaItem();
        }
    }

    public void precedente() {
        if (player.hasPreviousMediaItem()) {
            player.seekToPreviousMediaItem();
        }
    }

    public boolean staSuonando() {
        return player != null && player.isPlaying();
    }

    // ---- gestione della notifica ----

    /** Da Android 8 ogni notifica deve appartenere a un "canale". */
    private void creaCanaleNotifica() {
        NotificationChannel canale = new NotificationChannel(
                CANALE_ID,
                "Riproduzione musica",
                NotificationManager.IMPORTANCE_LOW // LOW = niente suono di avviso
        );
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(canale);
    }

    private Notification creaNotifica(String testo) {
        return new NotificationCompat.Builder(this, CANALE_ID)
                .setContentTitle("Bluetooth Music")
                .setContentText(testo)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true) // non si puo' scartare: il service e' attivo
                .build();
    }

    private void aggiornaNotifica(String testo) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.notify(NOTIFICA_ID, creaNotifica("In riproduzione: " + testo));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Liberiamo il player: senza questo si "perde" memoria.
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
