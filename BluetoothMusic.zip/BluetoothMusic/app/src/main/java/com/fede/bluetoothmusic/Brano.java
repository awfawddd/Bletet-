package com.fede.bluetoothmusic;

import android.net.Uri;

/**
 * Brano
 * -----
 * Rappresenta una canzone trovata sul telefono: titolo, artista e l'URI
 * (l'indirizzo) del file audio che il player usera' per riprodurlo.
 */
public class Brano {

    private final String titolo;
    private final String artista;
    private final Uri uri;

    public Brano(String titolo, String artista, Uri uri) {
        this.titolo = (titolo == null || titolo.isEmpty()) ? "Senza titolo" : titolo;
        this.artista = (artista == null || artista.isEmpty()) ? "Sconosciuto" : artista;
        this.uri = uri;
    }

    public String getTitolo()  { return titolo; }
    public String getArtista() { return artista; }
    public Uri getUri()        { return uri; }
}
